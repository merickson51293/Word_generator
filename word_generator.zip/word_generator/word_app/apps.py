from django.apps import AppConfig


class WordAppConfig(AppConfig):
    name = 'word_app'
